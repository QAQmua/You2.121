import SwiftUI

// 📄 微信主界面框架 (四大 TabView 骨架 + 顶部菜单)
struct WeChatMainView: View {
    @Binding var show: Bool
    @Binding var isLoggedIn: Bool
    @StateObject private var viewModel = WeChatViewModel()
    @ObservedObject var appearance = SystemAppearance.shared 
    
    @State private var selectedTab = 0
    @State private var showActionSheet = false
    
    var body: some View {
        TabView(selection: $selectedTab) {
            // Tab 1: 微信
            NavigationStack {
                WeChatChatListView(viewModel: viewModel)
                    .navigationTitle("微信".tr)
                    .navigationBarTitleDisplayMode(.inline)
                    .toolbar {
                        ToolbarItem(placement: .topBarTrailing) {
                            Button(action: { showActionSheet = true }) {
                                Image(systemName: "plus.circle").foregroundColor(.primary)
                            }
                        }
                    }
            }
            .tabItem { 
                Image(systemName: selectedTab == 0 ? "message.fill" : "message")
                Text("微信".tr) 
            }
            .tag(0)
            
            // Tab 2: 通讯录
            NavigationStack {
                WeChatContactsView()
                    .navigationTitle("通讯录".tr)
                    .navigationBarTitleDisplayMode(.inline)
                    .toolbar {
                        ToolbarItem(placement: .topBarTrailing) {
                            Button(action: { showActionSheet = true }) {
                                Image(systemName: "person.badge.plus").foregroundColor(.primary)
                            }
                        }
                    }
            }
            .tabItem { 
                Image(systemName: selectedTab == 1 ? "person.2.fill" : "person.2")
                Text("通讯录".tr) 
            }
            .tag(1)
            
            // Tab 3: 发现
            NavigationStack {
                WeChatDiscoverView()
                    .navigationTitle("发现".tr)
                    .navigationBarTitleDisplayMode(.inline)
            }
            .tabItem { 
                Image(systemName: selectedTab == 2 ? "safari.fill" : "safari")
                Text("发现".tr) 
            }
            .tag(2)
            
            // Tab 4: 我
            NavigationStack {
                WeChatMeView(isLoggedIn: $isLoggedIn)
                    .navigationTitle("")
                    .navigationBarTitleDisplayMode(.inline)
            }
            .tabItem { 
                Image(systemName: selectedTab == 3 ? "person.fill" : "person")
                Text("我".tr) 
            }
            .tag(3)
        }
        // 🌟 核心同步：跟随系统底部标签栏选中高亮色彩
        .tint(appearance.tabBarSelectedColor)
        .background(Color(UIColor.systemBackground))
        .confirmationDialog("操作".tr, isPresented: $showActionSheet) {
            Button("发起群聊".tr) { }
            Button("添加朋友".tr) { }
            Button("扫一扫".tr) { }
            Button("收付款".tr) { }
            Button("取消".tr, role: .cancel) { }
        }
    }
}
