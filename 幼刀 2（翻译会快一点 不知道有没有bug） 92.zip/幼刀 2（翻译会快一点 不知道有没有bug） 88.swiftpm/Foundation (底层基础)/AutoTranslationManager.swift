import SwiftUI

// 📄 语言枚举
enum AppLanguage: String, CaseIterable, Identifiable, Codable {
    case simplifiedChinese = "zh-Hans"
    case traditionalChinese = "zh-Hant"
    case english = "en"
    case japanese = "ja"
    case korean = "ko"
    
    var id: String { self.rawValue }
    
    var displayName: String {
        switch self {
        case .simplifiedChinese: return "简体中文"
        case .traditionalChinese: return "繁體中文"
        case .english: return "English"
        case .japanese: return "日本語"
        case .korean: return "한국어"
        }
    }
    
    var localeIdentifier: String {
        switch self {
        case .simplifiedChinese: return "zh_CN"
        case .traditionalChinese: return "zh_TW"
        case .english: return "en_US"
        case .japanese: return "ja_JP"
        case .korean: return "ko_KR"
        }
    }
    
    var apiTargetCode: String {
        switch self {
        case .simplifiedChinese: return "zh-CN"
        case .traditionalChinese: return "zh_TW"
        case .english: return "en"
        case .japanese: return "ja"
        case .korean: return "ko"
        }
    }
}

// 📄 核心多语言系统管理器与静态字典
class LanguageManager: ObservableObject {
    static let shared = LanguageManager()
    private let languageKey = "App_Selected_Language_Code"
    
    @Published var currentLanguage: AppLanguage = .simplifiedChinese {
        didSet {
            UserDefaults.standard.set(currentLanguage.rawValue, forKey: languageKey)
            AutoTranslationManager.shared.objectWillChange.send()
        }
    }
    
    init() {
        if let savedCode = UserDefaults.standard.string(forKey: languageKey),
           let lang = AppLanguage(rawValue: savedCode) {
            self.currentLanguage = lang
        } else {
            self.currentLanguage = .simplifiedChinese
        }
    }
    
    let dict: [String: [AppLanguage: String]] = [
        "app_phone": [.simplifiedChinese: "电话", .traditionalChinese: "電話", .english: "Phone", .japanese: "電話", .korean: "전화"],
        "app_settings": [.simplifiedChinese: "设置", .traditionalChinese: "設定", .english: "Settings", .japanese: "設定", .korean: "설정"],
        "app_wechat": [.simplifiedChinese: "微信", .traditionalChinese: "微信", .english: "WeChat", .japanese: "メッセージ", .korean: "메시지"],
        "app_iscreen": [.simplifiedChinese: "iScreen", .traditionalChinese: "iScreen", .english: "iScreen", .japanese: "iScreen", .korean: "iScreen"],
        "app_messages": [.simplifiedChinese: "信息", .traditionalChinese: "訊息", .english: "Messages", .japanese: "メッセージ", .korean: "메시지"],
        "app_weather": [.simplifiedChinese: "天气", .traditionalChinese: "天氣", .english: "Weather", .japanese: "天気", .korean: "날씨"],
        "app_anonymous": [.simplifiedChinese: "匿名", .traditionalChinese: "匿名", .english: "Anonymous", .japanese: "匿名", .korean: "익명"],
        "app_qimao": [.simplifiedChinese: "七猫小说", .traditionalChinese: "七貓小說", .english: "Qimao Novel", .japanese: "七猫小説", .korean: "칠묘소설"],
        "app_icity": [.simplifiedChinese: "iCity", .traditionalChinese: "iCity", .english: "iCity", .japanese: "iCity", .korean: "iCity"],
        "app_notes": [.simplifiedChinese: "手记", .traditionalChinese: "手記", .english: "Notes", .japanese: "ノート", .korean: "수첩"],
        "carrier_name": [.simplifiedChinese: "中国联通", .traditionalChinese: "中華電信", .english: "Carrier", .japanese: "docomo", .korean: "SKT"],
        "edit": [.simplifiedChinese: "编辑", .traditionalChinese: "編輯", .english: "Edit", .japanese: "編集", .korean: "편집"],
        "done": [.simplifiedChinese: "完成", .traditionalChinese: "完成", .english: "Done", .japanese: "完了", .korean: "완료"],
        "search": [.simplifiedChinese: "搜索", .traditionalChinese: "搜尋", .english: "Search", .japanese: "検索", .korean: "검색"],
        "add_widget_nav_title": [.simplifiedChinese: "添加小组件", .traditionalChinese: "加入小工具", .english: "Add Widget", .japanese: "ウィジェットを追加", .korean: "위젯 추가"],
        "close": [.simplifiedChinese: "关闭", .traditionalChinese: "關閉", .english: "Close", .japanese: "閉じる", .korean: "닫기"],
        "cat_all": [.simplifiedChinese: "全部", .traditionalChinese: "全部", .english: "All", .japanese: "すべて", .korean: "전체"],
        "widget_ins_title": [.simplifiedChinese: "ins发布页", .traditionalChinese: "ins發布頁", .english: "Instagram Post", .japanese: "投稿カード", .korean: "인스타 게시물"],
        "sub_ins": [.simplifiedChinese: "Ins 风格图文展示小组件", .traditionalChinese: "Ins 風格圖文展示小工具", .english: "Instagram style post widget", .japanese: "Ins風の写真カード", .korean: "인스타 스타일 게시물 위젯"],
        "widget_korean_title": [.simplifiedChinese: "寄语卡片", .traditionalChinese: "寄語卡片", .english: "Quote Card", .japanese: "メッセージカード", .korean: "메시지 카드"],
        "sub_korean": [.simplifiedChinese: "韩系简约每日寄语卡片", .traditionalChinese: "韓系簡約每日寄語卡片", .english: "Korean minimal daily quote card", .japanese: "シンプルな韓国風カード", .korean: "심플한 데일리 메시지 카드"],
        "widget_bubble_title": [.simplifiedChinese: "对话框", .traditionalChinese: "對話框", .english: "Chat Bubble", .japanese: "チャットバブル", .korean: "대话 상자"],
        "sub_bubble": [.simplifiedChinese: "聊天气泡风格小组件", .traditionalChinese: "聊天氣泡風格小工具", .english: "Chat bubble widget", .japanese: "吹き出しウィジェット", .korean: "채팅 말풍선 위젯"],
        "widget_photo_title": [.simplifiedChinese: "卡片", .traditionalChinese: "卡片", .english: "Photo Card", .japanese: "フォトカード", .korean: "사진 카드"],
        "sub_photo": [.simplifiedChinese: "桌面精选照片展示卡片", .traditionalChinese: "桌面精選照片展示卡片", .english: "Featured photo display card", .japanese: "お気に入り写真カード", .korean: "홈 화면 사진 카드"],
        "badge_4x4": [.simplifiedChinese: "4×4 大号", .traditionalChinese: "4×4 大號", .english: "4×4 Large", .japanese: "4×4 大", .korean: "4×4 대형"],
        "badge_4x2": [.simplifiedChinese: "4×2 中号", .traditionalChinese: "4×2 中號", .english: "4×2 Medium", .japanese: "4×2 中", .korean: "4×2 중형"],
        "badge_2x2": [.simplifiedChinese: "2×2 小号", .traditionalChinese: "2×2 小號", .english: "2×2 Small", .japanese: "2×2 Small", .korean: "2×2 소형"],
        "already_added": [.simplifiedChinese: "已在主屏幕", .traditionalChinese: "已在主畫面", .english: "Added to Home Screen", .japanese: "追加済み", .korean: "추가됨"],
        "add_to_home": [.simplifiedChinese: "添加小组件到主屏幕", .traditionalChinese: "加入小工具到主畫面", .english: "Add Widget to Home Screen", .japanese: "ホーム画面に追加", .korean: "홈 화면에 위젯 추가"],
        "settings_title": [.simplifiedChinese: "设置", .traditionalChinese: "設定", .english: "Settings", .japanese: "設定", .korean: "설정"],
        "device_name": [.simplifiedChinese: "极客手机", .traditionalChinese: "極客手機", .english: "Geek Phone", .japanese: "マイ端末", .korean: "마이 폰"],
        "apple_id_sub": [.simplifiedChinese: "Apple ID、iCloud、媒体与购买项目", .traditionalChinese: "Apple ID、iCloud、媒體與購買項目", .english: "Apple ID, iCloud, Media & Purchases", .japanese: "Apple ID、iCloud、メディアと購入", .korean: "Apple ID, iCloud, 미디어 및 구입 항목"],
        "language_title": [.simplifiedChinese: "语言", .traditionalChinese: "語言", .english: "Language", .japanese: "言語", .korean: "언어"],
        "display_and_brightness": [.simplifiedChinese: "显示与亮度", .traditionalChinese: "螢幕顯示與亮度", .english: "Display & Brightness", .japanese: "画面表示と明るさ", .korean: "디스플레이 및 밝기"],
        "wallpaper": [.simplifiedChinese: "壁纸", .traditionalChinese: "背景圖片", .english: "Wallpaper", .japanese: "壁紙", .korean: "배경화면"],
        "api_config": [.simplifiedChinese: "API 反代配置", .traditionalChinese: "API 反向代理配置", .english: "API Reverse Proxy", .japanese: "APIプロキシ設定", .korean: "API 프록시 설정"],
        "model_selection": [.simplifiedChinese: "大模型选择", .traditionalChinese: "大模型選擇", .english: "AI Model Selection", .japanese: "AIモデル選択", .korean: "AI 모델 선택"],
        "appearance": [.simplifiedChinese: "外观", .traditionalChinese: "外觀", .english: "Appearance", .japanese: "外観モード", .korean: "화面 모드"],
        "appearance_auto_footer": [.simplifiedChinese: "开启自动后，将跟随您设备的日夜间模式自动切换系统颜色。", .traditionalChinese: "開啟自動後，將跟隨您設備的日夜間模式自動切換系统颜色。", .english: "When automatic is enabled, appearance matches device dark/light mode.", .japanese: "自動をオンにすると、デバイスの外観設定に合わせて切り替わります。", .korean: "자동을 켜면 기기의 다크/라이트 모드에 맞춰 테마가 전환됩니다."],
        "auto": [.simplifiedChinese: "自动", .traditionalChinese: "自動", .english: "Automatic", .japanese: "自動", .korean: "자동"],
        "appearance_selection": [.simplifiedChinese: "外观选择", .traditionalChinese: "外觀選擇", .english: "Appearance Style", .japanese: "外観の選択", .korean: "화面 스타일"],
        "light": [.simplifiedChinese: "浅色", .traditionalChinese: "淺色", .english: "Light", .japanese: "ライト", .korean: "라이特"],
        "dark": [.simplifiedChinese: "深色", .traditionalChinese: "深色", .english: "Dark", .japanese: "ダーク", .korean: "다크"],
        "font_weight_section": [.simplifiedChinese: "系统字体粗细", .traditionalChinese: "系統字體粗細", .english: "System Font Weight", .japanese: "フォントの太さ", .korean: "서체 굵기"],
        "widget_font_priority": [.simplifiedChinese: "组件字体优先级", .traditionalChinese: "小工具字體優先級", .english: "Widget Font Priority", .japanese: "ウィジェットフォント優先", .korean: "위젯 서체 우선순위"],
        "widget_font_priority_footer": [.simplifiedChinese: "开启后，组件内自定义设置的字体样式优先显示，不被系统字体粗细覆盖；关闭后，所有组件统一遵从系统字体设置。", .traditionalChinese: "開啟後，小工具內自訂設定的字體樣式優先顯示，不被系統字體粗細覆蓋；關閉後，所有小工具統一遵從系統字體設定。", .english: "When enabled, custom widget font styles take priority over system font weight.", .japanese: "オンにすると、ウィジェット独自のフォント設定が優先されます。", .korean: "켜짐으로 설정하면 위젯의 사용자 지정 서체가 시스템 서体 굵기보다 우선 적용됩니다."],
        "desktop_and_indicators": [.simplifiedChinese: "桌面布局与指示器", .traditionalChinese: "桌面佈局與指示器", .english: "Desktop & Indicators", .japanese: "ホーム画面とインジケータ", .korean: "홈 화면 및 인디케이터"],
        "hide_home_indicator": [.simplifiedChinese: "隐藏底部指示条", .traditionalChinese: "隱藏底部指示條", .english: "Hide Home Bar", .japanese: "ホームバーを非表示", .korean: "홈 바 가리기"],
        "hide_status_bar": [.simplifiedChinese: "隐藏顶部状态栏", .traditionalChinese: "隱藏頂部狀態列", .english: "Hide Status Bar", .japanese: "ステータスバーを非表示", .korean: "상태 바 가리기"],
        "lock_screen": [.simplifiedChinese: "锁定屏幕", .traditionalChinese: "鎖定畫面", .english: "Lock Screen", .japanese: "ロック画面", .korean: "잠금 화면"],
        "home_screen": [.simplifiedChinese: "主屏幕", .traditionalChinese: "主畫面", .english: "Home Screen", .japanese: "홈 화면"],
        "customize": [.simplifiedChinese: "自定义", .traditionalChinese: "自訂", .english: "Customize", .japanese: "カスタマイズ", .korean: "사용자화"],
        "under_development": [.simplifiedChinese: "待开发", .traditionalChinese: "待開發", .english: "Coming Soon", .japanese: "開発中", .korean: "개발 중"]
    ]
    
    func tr(_ key: String) -> String {
        let trimmed = key.trimmingCharacters(in: .whitespacesAndNewlines)
        if let match = dict[trimmed]?[currentLanguage] { return match }
        return AutoTranslationManager.shared.translate(trimmed, to: currentLanguage)
    }
}

extension String {
    var tr: String { LanguageManager.shared.tr(self) }
}

// 📄 实时在线翻译引擎
class AutoTranslationManager: ObservableObject {
    static let shared = AutoTranslationManager()
    
    private let cacheKey = "App_Auto_Translation_Live_Store_V9"
    @Published var translationCache: [String: [String: String]] = [:]
    
    private var inFlightRequests = Set<String>()
    private var debounceTask: Task<Void, Never>?
    
    init() {
        if let data = UserDefaults.standard.data(forKey: cacheKey),
           let decoded = try? JSONDecoder().decode([String: [String: String]].self, from: data) {
            self.translationCache = decoded
        }
    }
    
    private func saveCache() {
        let snapshot = self.translationCache
        Task.detached(priority: .utility) {
            if let data = try? JSONEncoder().encode(snapshot) {
                UserDefaults.standard.set(data, forKey: "App_Auto_Translation_Live_Store_V9")
            }
        }
    }
    
    func prewarm(text: String) {
        let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return }
        
        debounceTask?.cancel()
        debounceTask = Task {
            try? await Task.sleep(nanoseconds: 400_000_000)
            guard !Task.isCancelled else { return }
            
            for lang in AppLanguage.allCases where lang != .simplifiedChinese {
                _ = await translateAsync(trimmed, to: lang)
            }
        }
    }
    
    func translate(_ text: String, to targetLang: AppLanguage? = nil) -> String {
        let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return text }
        
        let lang = targetLang ?? LanguageManager.shared.currentLanguage
        if lang == .simplifiedChinese { return text }
        
        if let keyMatch = LanguageManager.shared.dict[trimmed]?[lang] { return keyMatch }
        
        if lang == .traditionalChinese {
            let str = trimmed as NSString
            if let converted = str.applyingTransform(StringTransform("Hans-Hant"), reverse: false) {
                return converted
            }
        }
        
        if let cached = translationCache[trimmed]?[lang.rawValue], !cached.isEmpty {
            return cached
        }
        
        let reqKey = "\(trimmed)_\(lang.rawValue)"
        if !inFlightRequests.contains(reqKey) {
            inFlightRequests.insert(reqKey)
            Task.detached(priority: .utility) {
                _ = await self.translateAsync(trimmed, to: lang)
            }
        }
        
        return text
    }
    
    func translateAsync(_ text: String, to targetLang: AppLanguage? = nil) async -> String {
        let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return text }
        
        let lang = targetLang ?? LanguageManager.shared.currentLanguage
        if lang == .simplifiedChinese { return text }
        
        if let cached = translationCache[trimmed]?[lang.rawValue], !cached.isEmpty { return cached }
        if let keyMatch = LanguageManager.shared.dict[trimmed]?[lang] { return keyMatch }
        
        var allowed = CharacterSet.urlQueryAllowed
        allowed.remove(charactersIn: "+&=?")
        guard let encoded = trimmed.addingPercentEncoding(withAllowedCharacters: allowed) else {
            return text
        }
        
        let targetCode = lang.apiTargetCode
        if let url = URL(string: "https://translate.googleapis.com/translate_a/single?client=gtx&sl=zh-CN&tl=\(targetCode)&dt=t&q=\(encoded)") {
            var req = URLRequest(url: url)
            req.timeoutInterval = 2.5
            if let (data, resp) = try? await URLSession.shared.data(for: req),
               let httpResp = resp as? HTTPURLResponse, httpResp.statusCode == 200,
               let json = try? JSONSerialization.jsonObject(with: data) as? [Any],
               let firstArr = json.first as? [Any] {
                var clean = ""
                for item in firstArr {
                    if let part = item as? [Any], let piece = part.first as? String {
                        clean += piece
                    }
                }
                let finalResult = clean
                if !finalResult.isEmpty && finalResult != text {
                    await MainActor.run { () -> Void in
                        var existing = self.translationCache[trimmed] ?? [:]
                        existing[lang.rawValue] = finalResult
                        self.translationCache[trimmed] = existing
                        self.saveCache()
                        self.inFlightRequests.remove("\(trimmed)_\(lang.rawValue)")
                        self.objectWillChange.send()
                    }
                    return finalResult
                }
            }
        }
        
        await MainActor.run { () -> Void in
            self.inFlightRequests.remove("\(trimmed)_\(lang.rawValue)")
        }
        return text
    }
}
