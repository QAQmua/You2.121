// 📄 完整替换文件：IScreenApp/IScreenHomeView.swift
import SwiftUI

// MARK: - 1. 通用等比例小组件本体渲染器
struct ScaledWidgetPreview: View {
    let widget: WidgetDefinition
    let targetWidth: CGFloat
    let targetHeight: CGFloat
    var refreshID: UUID = UUID()
    
    @ObservedObject private var insManager = InsPostWidgetManager.shared
    
    var body: some View {
        let s = uiScale
        let baseWidth: CGFloat = (widget.sizeCols >= 4 ? 340.0 : 160.0) * s
        let baseHeight: CGFloat = (widget.sizeRows >= 4 ? 330.0 : (widget.sizeCols >= 4 ? 156.0 : 160.0)) * s
        let scale = min(targetWidth / baseWidth, targetHeight / baseHeight)
        
        ZStack {
            widget.desktopView()
                .frame(width: baseWidth, height: baseHeight)
                .scaleEffect(scale)
                .allowsHitTesting(false)
        }
        .frame(width: targetWidth, height: targetHeight)
        .clipped()
        .clipShape(RoundedRectangle(cornerRadius: 22.0 * s * scale, style: .continuous))
        .shadow(color: Color.black.opacity(0.06), radius: 8.0 * scale, y: 4.0 * scale)
        .contentShape(Rectangle())
        .id("\(widget.id)_\(refreshID)")
    }
}

// MARK: - 2. 首页主视图
struct IScreenHomeView: View {
    @ObservedObject var viewModel: IScreenViewModel
    @ObservedObject var appearance = SystemAppearance.shared
    @ObservedObject var registry = WidgetRegistry.shared
    @ObservedObject var lang = LanguageManager.shared
    
    @FocusState var isSearchFocused: Bool
    
    var body: some View {
        VStack(spacing: 0) {
            searchBarHeaderView
            
            if viewModel.isSearching {
                searchHistoryAndResultView
            } else {
                homeWidgetFlowScrollView
            }
        }
    }
    
    private var searchBarHeaderView: some View {
        HStack(spacing: 0) {
            HStack(spacing: 8) {
                Image(systemName: "magnifyingglass")
                    .font(.system(size: 15, weight: .medium))
                    .foregroundColor(.secondary)
                
                TextField("搜索小组件、图标主题...".tr, text: $viewModel.searchText)
                    .font(.system(size: 14, weight: appearance.systemFontWeight))
                    .foregroundColor(.primary)
                    .focused($isSearchFocused)
                
                if !viewModel.searchText.isEmpty {
                    Button(action: { viewModel.searchText = "" }) {
                        Image(systemName: "xmark.circle.fill").font(.system(size: 14)).foregroundColor(.secondary)
                    }
                }
            }
            .frame(maxWidth: .infinity)
            .frame(height: 38)
            .padding(.horizontal, 12)
            .background(Color(UIColor.secondarySystemFill))
            .clipShape(RoundedRectangle(cornerRadius: 11, style: .continuous))
            
            if viewModel.isSearching {
                Button(action: {
                    withAnimation(.easeInOut(duration: 0.22)) {
                        isSearchFocused = false
                        viewModel.isSearching = false
                        viewModel.searchText = ""
                    }
                }) {
                    Text("取消".tr)
                        .font(.system(size: 16, weight: appearance.systemFontWeight))
                        .foregroundColor(.gray)
                        .padding(.leading, 12)
                        .fixedSize()
                }
                .transition(.move(edge: .trailing).combined(with: .opacity))
            }
        }
        .padding(.horizontal, 16)
        .padding(.top, 10)
        .padding(.bottom, 6)
        .animation(.easeInOut(duration: 0.22), value: viewModel.isSearching)
        .onChange(of: isSearchFocused) { _, focused in
            if focused && !viewModel.isSearching {
                withAnimation(.easeInOut(duration: 0.22)) { viewModel.isSearching = true }
            }
        }
    }
    
    private var homeWidgetFlowScrollView: some View {
        GeometryReader { geo in
            let availableWidth = max(geo.size.width - 32, 1)
            let spacing: CGFloat = 14
            
            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 16) {
                    categoryFilterBar
                    
                    let filteredWidgets = registry.registeredWidgets.filter {
                        isWidgetMatchingFilter(widget: $0, filter: viewModel.selectedCategoryFilter)
                    }
                    
                    let displayRows = buildDisplayRows(from: filteredWidgets)
                    
                    VStack(spacing: 20) {
                        ForEach(displayRows) { row in
                            Group {
                                switch row {
                                case .double2x2(let left, let right):
                                    let halfWidth = (availableWidth - spacing) / 2.0
                                    HStack(spacing: spacing) {
                                        widgetInteractiveCell(widget: left, width: halfWidth, height: halfWidth)
                                        widgetInteractiveCell(widget: right, width: halfWidth, height: halfWidth)
                                    }
                                    
                                case .single(let widget):
                                    if widget.sizeCols >= 4 && widget.sizeRows >= 4 {
                                        let size4x4Height = availableWidth * (330.0 / 340.0)
                                        widgetInteractiveCell(widget: widget, width: availableWidth, height: size4x4Height)
                                    } else if widget.sizeCols >= 4 && widget.sizeRows == 2 {
                                        let height4x2 = availableWidth * (156.0 / 340.0)
                                        widgetInteractiveCell(widget: widget, width: availableWidth, height: height4x2)
                                    } else {
                                        let size2x2 = (availableWidth - spacing) / 2.0
                                        HStack {
                                            widgetInteractiveCell(widget: widget, width: size2x2, height: size2x2)
                                            Spacer()
                                        }
                                    }
                                }
                            }
                        }
                    }
                    .padding(.horizontal, 16)
                    .padding(.bottom, 28)
                }
                .animation(.spring(response: 0.3, dampingFraction: 0.86), value: viewModel.selectedCategoryFilter)
            }
        }
    }
    
    private func widgetInteractiveCell(widget: WidgetDefinition, width: CGFloat, height: CGFloat) -> some View {
        ScaledWidgetPreview(widget: widget, targetWidth: width, targetHeight: height, refreshID: viewModel.refreshUUID)
            .contentShape(Rectangle())
            .onTapGesture {
                UIImpactFeedbackGenerator(style: .light).impactOccurred()
                withAnimation(.spring(response: 0.32, dampingFraction: 0.86)) {
                    viewModel.activeEditWidgetID = widget.id
                }
            }
    }
    
    // MARK: - 分类标签条（使用全局分类标签颜色）
    private var categoryFilterBar: some View {
        HStack(spacing: 8) {
            ForEach(viewModel.categoryFilters, id: \.self) { filter in
                Button(action: {
                    UIImpactFeedbackGenerator(style: .light).impactOccurred()
                    withAnimation(.spring(response: 0.28, dampingFraction: 0.85)) {
                        viewModel.selectedCategoryFilter = filter
                    }
                }) {
                    Text(filter == "全部" ? "全部".tr : filter)
                        .font(.system(size: 12, weight: viewModel.selectedCategoryFilter == filter ? .semibold : appearance.systemFontWeight))
                        .padding(.horizontal, 14)
                        .padding(.vertical, 6)
                        .background(viewModel.selectedCategoryFilter == filter ? appearance.categoryTagColor : Color(UIColor.secondarySystemFill))
                        .foregroundColor(viewModel.selectedCategoryFilter == filter ? .white : .secondary)
                        .clipShape(Capsule())
                }
            }
            Spacer()
        }
        .padding(.horizontal, 16)
        .padding(.top, 4)
    }
    
    private var searchHistoryAndResultView: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 20) {
                if viewModel.searchText.trimmingCharacters(in: .whitespaces).isEmpty {
                    VStack(alignment: .leading, spacing: 12) {
                        HStack {
                            Text("搜索历史".tr).font(.system(size: 14, weight: appearance.systemFontWeight)).foregroundColor(.secondary)
                            Spacer()
                            if !viewModel.searchHistory.isEmpty {
                                Button(action: { withAnimation { viewModel.searchHistory.removeAll() } }) {
                                    Image(systemName: "trash").font(.caption).foregroundColor(.secondary)
                                }
                            }
                        }
                        if viewModel.searchHistory.isEmpty {
                            Text("暂无搜索历史".tr).font(.caption).foregroundColor(.secondary.opacity(0.6)).padding(.top, 4)
                        } else {
                            FlowLayout(spacing: 8) {
                                ForEach(viewModel.searchHistory, id: \.self) { item in
                                    Button(action: { viewModel.searchText = item }) {
                                        Text(item.tr)
                                            .font(.system(size: 12, weight: appearance.systemFontWeight))
                                            .foregroundColor(.primary)
                                            .padding(.horizontal, 12)
                                            .padding(.vertical, 6)
                                            .background(Color(UIColor.secondarySystemFill))
                                            .clipShape(Capsule())
                                    }
                                }
                            }
                        }
                    }
                    .padding(.horizontal, 16)
                    .padding(.top, 8)
                } else {
                    let results = registry.registeredWidgets.filter {
                        lang.tr($0.titleKey).localizedCaseInsensitiveContains(viewModel.searchText) ||
                        lang.tr($0.subtitleKey).localizedCaseInsensitiveContains(viewModel.searchText)
                    }
                    
                    VStack(alignment: .leading, spacing: 14) {
                        Text("\("搜索结果".tr) (\(results.count))").font(.caption).foregroundColor(.secondary).padding(.horizontal, 16)
                        if results.isEmpty {
                            VStack(spacing: 12) {
                                Image(systemName: "magnifyingglass").font(.system(size: 32)).foregroundColor(.secondary.opacity(0.4)).padding(.top, 40)
                                Text("\("未找到与".tr)“\(viewModel.searchText)”\("相关的内容".tr)").font(.subheadline).foregroundColor(.secondary)
                            }
                            .frame(maxWidth: .infinity)
                        } else {
                            GeometryReader { searchGeo in
                                let totalW = max(searchGeo.size.width - 32, 1)
                                VStack(spacing: 16) {
                                    ForEach(results) { widget in
                                        if widget.sizeCols >= 4 {
                                            let height = widget.sizeRows >= 4 ? (totalW * (330.0 / 340.0)) : (totalW * (156.0 / 340.0))
                                            widgetInteractiveCell(widget: widget, width: totalW, height: height)
                                        } else {
                                            let size2x2 = min(totalW * 0.48, 165.0 * uiScale)
                                            HStack {
                                                widgetInteractiveCell(widget: widget, width: size2x2, height: size2x2)
                                                Spacer()
                                            }
                                        }
                                    }
                                }
                                .padding(.horizontal, 16)
                            }
                            .frame(minHeight: 400)
                        }
                    }
                }
            }
            .padding(.top, 8)
            .padding(.bottom, 20)
        }
    }
    
    private func buildDisplayRows(from widgets: [WidgetDefinition]) -> [HomeDisplayRow] {
        var rows: [HomeDisplayRow] = []
        var queue = widgets
        
        while !queue.isEmpty {
            let first = queue.removeFirst()
            
            if first.sizeCols == 2 && first.sizeRows == 2 {
                if let next2x2Idx = queue.firstIndex(where: { $0.sizeCols == 2 && $0.sizeRows == 2 }) {
                    let second = queue.remove(at: next2x2Idx)
                    rows.append(.double2x2(first, second))
                    continue
                }
                rows.append(.single(first))
                continue
            }
            
            rows.append(.single(first))
        }
        
        return rows
    }
    
    private func isWidgetMatchingFilter(widget: WidgetDefinition, filter: String) -> Bool {
        if filter == "全部" { return true }
        let target = filter.lowercased().replacingOccurrences(of: "×", with: "x")
        let badge = widget.sizeBadgeKey.lowercased().replacingOccurrences(of: "×", with: "x")
        if target == badge { return true }
        
        switch target {
        case "2x2": return widget.sizeCols == 2 && widget.sizeRows == 2
        case "4x2": return (widget.sizeCols == 4 && widget.sizeRows == 2) || (widget.sizeCols == 2 && widget.sizeRows == 4)
        case "4x4": return widget.sizeCols == 4 && widget.sizeRows == 4
        default: return false
        }
    }
}

// MARK: - 舒展行排版定义
enum HomeDisplayRow: Identifiable {
    case double2x2(WidgetDefinition, WidgetDefinition)
    case single(WidgetDefinition)
    
    var id: String {
        switch self {
        case .double2x2(let a, let b): return "\(a.id)_\(b.id)"
        case .single(let a): return a.id
        }
    }
}
