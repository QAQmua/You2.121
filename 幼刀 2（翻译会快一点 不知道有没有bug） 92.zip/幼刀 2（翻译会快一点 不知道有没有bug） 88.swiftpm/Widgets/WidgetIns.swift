// 📄 完整替换文件：Widgets/WidgetIns.swift
import SwiftUI
import PhotosUI

final class InsWidgetPlugin: BaseWidgetPlugin {
    @MainActor override class func register() {
        WidgetRegistry.shared.registerInsWidget()
    }
}

class InsPostWidgetManager: ObservableObject {
    static let shared = InsPostWidgetManager()
    
    private let avatarIdKey = "App_Widget_Ins_AvatarID"
    private let postImageIdKey = "App_Widget_Ins_PostImageID"
    
    private let addedKey = "App_Widget_Ins_IsAdded"
    private let pageKey = "App_Widget_Ins_PagePosition"
    private let rowKey = "App_Widget_Ins_RowPosition"
    private let isTransparentKey = "App_Widget_Ins_IsTransparent"
    private let bgColorKey = "App_Widget_Ins_BgColor"
    private let pinPreviewKey = "App_Widget_Ins_PinPreview"
    private let avatarSizeKey = "App_Widget_Ins_AvatarSize"
    
    private let hasBorderKey = "App_Widget_Ins_HasBorder"
    private let borderWidthKey = "App_Widget_Ins_BorderWidth"
    private let borderColorKey = "App_Widget_Ins_BorderColor"
    
    private let cancelTextKey = "App_Widget_Ins_CancelText"
    private let cancelSizeKey = "App_Widget_Ins_CancelSize"
    private let cancelWeightKey = "App_Widget_Ins_CancelWeight"
    private let cancelColorKey = "App_Widget_Ins_CancelColor"
    
    private let titleTextKey = "App_Widget_Ins_TitleText"
    private let titleSizeKey = "App_Widget_Ins_TitleSize"
    private let titleWeightKey = "App_Widget_Ins_TitleWeight"
    private let titleColorKey = "App_Widget_Ins_TitleColor"
    
    private let sendTextKey = "App_Widget_Ins_SendText"
    private let sendSizeKey = "App_Widget_Ins_SendSize"
    private let sendWeightKey = "App_Widget_Ins_SendWeight"
    private let sendColorKey = "App_Widget_Ins_SendColor"
    
    private let sendIconSizeKey = "App_Widget_Ins_SendIconSize"
    private let sendIconColorKey = "App_Widget_Ins_SendIconColor"
    private let sendIconOffsetXKey = "App_Widget_Ins_SendIconOffsetX"
    private let sendIconOffsetYKey = "App_Widget_Ins_SendIconOffsetY"
    
    private let authorNameKey = "App_Widget_Ins_AuthorName"
    private let authorNameSizeKey = "App_Widget_Ins_AuthorNameSize"
    private let authorNameWeightKey = "App_Widget_Ins_AuthorNameWeight"
    private let authorNameColorKey = "App_Widget_Ins_AuthorNameColor"
    
    private let subTextKey = "App_Widget_Ins_SubText"
    private let subTextSizeKey = "App_Widget_Ins_SubTextSize"
    private let subTextWeightKey = "App_Widget_Ins_SubTextWeight"
    private let subTextColorKey = "App_Widget_Ins_SubTextColor"
    
    // 🌟 地区定位坐标与艾特高亮设置键
    private let showLocationIconKey = "App_Widget_Ins_ShowLocationIcon"
    private let locationIconKey = "App_Widget_Ins_LocationIcon"
    private let locationIconColorKey = "App_Widget_Ins_LocationIconColor"
    private let mentionColorKey = "App_Widget_Ins_MentionColor"
    
    private let contentTextKey = "App_Widget_Ins_ContentText"
    private let contentTextSizeKey = "App_Widget_Ins_ContentTextSize"
    private let contentTextWeightKey = "App_Widget_Ins_ContentTextWeight"
    private let contentTextColorKey = "App_Widget_Ins_ContentTextColor"
    
    @Published var avatarImageData: Data? {
        didSet {
            let oldId = UserDefaults.standard.string(forKey: avatarIdKey)
            LocalImageStore.shared.replace(oldId: oldId, with: avatarImageData) { newId in
                UserDefaults.standard.set(newId, forKey: self.avatarIdKey)
            }
        }
    }
    
    @Published var postImageData: Data? {
        didSet {
            let oldId = UserDefaults.standard.string(forKey: postImageIdKey)
            LocalImageStore.shared.replace(oldId: oldId, with: postImageData) { newId in
                UserDefaults.standard.set(newId, forKey: self.postImageIdKey)
            }
        }
    }
    
    @Published var isAddedToDesktop: Bool { didSet { UserDefaults.standard.set(isAddedToDesktop, forKey: addedKey) } }
    @Published var widgetPage: Int { didSet { UserDefaults.standard.set(widgetPage, forKey: pageKey) } }
    @Published var widgetRow: Int { didSet { UserDefaults.standard.set(widgetRow, forKey: rowKey) } }
    @Published var isTransparentBackground: Bool { didSet { UserDefaults.standard.set(isTransparentBackground, forKey: isTransparentKey) } }
    @Published var backgroundColorHex: String { didSet { UserDefaults.standard.set(backgroundColorHex, forKey: bgColorKey) } }
    @Published var isPinPreviewToTop: Bool { didSet { UserDefaults.standard.set(isPinPreviewToTop, forKey: pinPreviewKey) } }
    @Published var avatarSize: Double { didSet { UserDefaults.standard.set(avatarSize, forKey: avatarSizeKey) } }
    
    @Published var hasBorder: Bool { didSet { UserDefaults.standard.set(hasBorder, forKey: hasBorderKey) } }
    @Published var borderWidth: Double { didSet { UserDefaults.standard.set(borderWidth, forKey: borderWidthKey) } }
    @Published var borderColorHex: String { didSet { UserDefaults.standard.set(borderColorHex, forKey: borderColorKey) } }
    
    @Published var headerCancelText: String {
        didSet {
            UserDefaults.standard.set(headerCancelText, forKey: cancelTextKey)
            AutoTranslationManager.shared.prewarm(text: headerCancelText)
        }
    }
    @Published var headerCancelSize: Double { didSet { UserDefaults.standard.set(headerCancelSize, forKey: cancelSizeKey) } }
    @Published var headerCancelWeightName: String { didSet { UserDefaults.standard.set(headerCancelWeightName, forKey: cancelWeightKey) } }
    @Published var headerCancelColorHex: String { didSet { UserDefaults.standard.set(headerCancelColorHex, forKey: cancelColorKey) } }
    
    @Published var headerTitle: String {
        didSet {
            UserDefaults.standard.set(headerTitle, forKey: titleTextKey)
            AutoTranslationManager.shared.prewarm(text: headerTitle)
        }
    }
    @Published var headerTitleSize: Double { didSet { UserDefaults.standard.set(headerTitleSize, forKey: titleSizeKey) } }
    @Published var headerTitleWeightName: String { didSet { UserDefaults.standard.set(headerTitleWeightName, forKey: titleWeightKey) } }
    @Published var headerTitleColorHex: String { didSet { UserDefaults.standard.set(headerTitleColorHex, forKey: titleColorKey) } }
    
    @Published var headerSendText: String {
        didSet {
            UserDefaults.standard.set(headerSendText, forKey: sendTextKey)
            AutoTranslationManager.shared.prewarm(text: headerSendText)
        }
    }
    @Published var headerSendSize: Double { didSet { UserDefaults.standard.set(headerSendSize, forKey: sendSizeKey) } }
    @Published var headerSendWeightName: String { didSet { UserDefaults.standard.set(headerSendWeightName, forKey: sendWeightKey) } }
    @Published var headerSendColorHex: String { didSet { UserDefaults.standard.set(headerSendColorHex, forKey: sendColorKey) } }
    
    @Published var sendIconSize: Double { didSet { UserDefaults.standard.set(sendIconSize, forKey: sendIconSizeKey) } }
    @Published var sendIconColorHex: String { didSet { UserDefaults.standard.set(sendIconColorHex, forKey: sendIconColorKey) } }
    @Published var sendIconOffsetX: Double { didSet { UserDefaults.standard.set(sendIconOffsetX, forKey: sendIconOffsetXKey) } }
    @Published var sendIconOffsetY: Double { didSet { UserDefaults.standard.set(sendIconOffsetY, forKey: sendIconOffsetYKey) } }
    
    @Published var authorName: String {
        didSet {
            UserDefaults.standard.set(authorName, forKey: authorNameKey)
            AutoTranslationManager.shared.prewarm(text: authorName)
        }
    }
    @Published var authorNameSize: Double { didSet { UserDefaults.standard.set(authorNameSize, forKey: authorNameSizeKey) } }
    @Published var authorNameWeightName: String { didSet { UserDefaults.standard.set(authorNameWeightName, forKey: authorNameWeightKey) } }
    @Published var authorNameColorHex: String { didSet { UserDefaults.standard.set(authorNameColorHex, forKey: authorNameColorKey) } }
    
    @Published var authorSubText: String {
        didSet {
            UserDefaults.standard.set(authorSubText, forKey: subTextKey)
            AutoTranslationManager.shared.prewarm(text: authorSubText)
        }
    }
    @Published var authorSubTextSize: Double { didSet { UserDefaults.standard.set(authorSubTextSize, forKey: subTextSizeKey) } }
    @Published var authorSubTextWeightName: String { didSet { UserDefaults.standard.set(authorSubTextWeightName, forKey: subTextWeightKey) } }
    @Published var authorSubTextColorHex: String { didSet { UserDefaults.standard.set(authorSubTextColorHex, forKey: subTextColorKey) } }
    
    // 🌟 地区定位坐标开关、坐标类型（默认经典镂空倒水滴 classic_pin）
    @Published var showLocationIcon: Bool { didSet { UserDefaults.standard.set(showLocationIcon, forKey: showLocationIconKey) } }
    @Published var selectedLocationIcon: String { didSet { UserDefaults.standard.set(selectedLocationIcon, forKey: locationIconKey) } }
    @Published var locationIconColorHex: String { didSet { UserDefaults.standard.set(locationIconColorHex, forKey: locationIconColorKey) } }
    @Published var mentionColorHex: String { didSet { UserDefaults.standard.set(mentionColorHex, forKey: mentionColorKey) } }
    
    @Published var contentText: String {
        didSet {
            UserDefaults.standard.set(contentText, forKey: contentTextKey)
            AutoTranslationManager.shared.prewarm(text: contentText)
        }
    }
    @Published var contentTextSize: Double { didSet { UserDefaults.standard.set(contentTextSize, forKey: contentTextSizeKey) } }
    @Published var contentTextWeightName: String { didSet { UserDefaults.standard.set(contentTextWeightName, forKey: contentTextWeightKey) } }
    @Published var contentTextColorHex: String { didSet { UserDefaults.standard.set(contentTextColorHex, forKey: contentTextColorKey) } }
    
    var backgroundColor: Color { Color(hex: backgroundColorHex) }
    var borderColor: Color { Color(hex: borderColorHex) }
    var headerCancelColor: Color { Color(hex: headerCancelColorHex) }
    var headerTitleColor: Color { Color(hex: headerTitleColorHex) }
    var headerSendColor: Color { Color(hex: headerSendColorHex) }
    var sendIconColor: Color { Color(hex: sendIconColorHex) }
    var authorNameColor: Color { Color(hex: authorNameColorHex) }
    var authorSubTextColor: Color { Color(hex: authorSubTextColorHex) }
    var locationIconColor: Color { Color(hex: locationIconColorHex) }
    var mentionColor: Color { Color(hex: mentionColorHex) }
    var contentTextColor: Color { Color(hex: contentTextColorHex) }
    
    var headerCancelWeight: Font.Weight { Font.Weight.from(name: headerCancelWeightName) }
    var headerTitleWeight: Font.Weight { Font.Weight.from(name: headerTitleWeightName) }
    var headerSendWeight: Font.Weight { Font.Weight.from(name: headerSendWeightName) }
    var authorNameWeight: Font.Weight { Font.Weight.from(name: authorNameWeightName) }
    var authorSubTextWeight: Font.Weight { Font.Weight.from(name: authorSubTextWeightName) }
    var contentTextWeight: Font.Weight { Font.Weight.from(name: contentTextWeightName) }
    
    init() {
        if let savedAvatarId = UserDefaults.standard.string(forKey: avatarIdKey) {
            self.avatarImageData = LocalImageStore.shared.load(id: savedAvatarId)
        }
        if let savedPostId = UserDefaults.standard.string(forKey: postImageIdKey) {
            self.postImageData = LocalImageStore.shared.load(id: savedPostId)
        }
        
        self.isAddedToDesktop = UserDefaults.standard.bool(forKey: addedKey)
        self.widgetPage = UserDefaults.standard.integer(forKey: pageKey)
        let rawRow = UserDefaults.standard.object(forKey: rowKey) != nil ? UserDefaults.standard.integer(forKey: rowKey) : 0
        self.widgetRow = min(max(0, rawRow), 2)
        self.isTransparentBackground = UserDefaults.standard.bool(forKey: isTransparentKey)
        self.backgroundColorHex = UserDefaults.standard.string(forKey: bgColorKey) ?? "#FFFFFF"
        self.isPinPreviewToTop = UserDefaults.standard.object(forKey: pinPreviewKey) != nil ? UserDefaults.standard.bool(forKey: pinPreviewKey) : true
        self.avatarSize = UserDefaults.standard.object(forKey: avatarSizeKey) != nil ? UserDefaults.standard.double(forKey: avatarSizeKey) : 40.0
        self.hasBorder = UserDefaults.standard.bool(forKey: hasBorderKey)
        self.borderWidth = UserDefaults.standard.object(forKey: borderWidthKey) != nil ? UserDefaults.standard.double(forKey: borderWidthKey) : 1.0
        self.borderColorHex = UserDefaults.standard.string(forKey: borderColorKey) ?? "#000000"
        self.headerCancelText = UserDefaults.standard.string(forKey: cancelTextKey) ?? "取消"
        self.headerCancelSize = UserDefaults.standard.object(forKey: cancelSizeKey) != nil ? UserDefaults.standard.double(forKey: cancelSizeKey) : 13.5
        self.headerCancelWeightName = UserDefaults.standard.string(forKey: cancelWeightKey) ?? "bold"
        self.headerCancelColorHex = UserDefaults.standard.string(forKey: cancelColorKey) ?? "#B5B5B5"
        self.headerTitle = UserDefaults.standard.string(forKey: titleTextKey) ?? "发布动态"
        self.headerTitleSize = UserDefaults.standard.object(forKey: titleSizeKey) != nil ? UserDefaults.standard.double(forKey: titleSizeKey) : 13.5
        self.headerTitleWeightName = UserDefaults.standard.string(forKey: titleWeightKey) ?? "bold"
        self.headerTitleColorHex = UserDefaults.standard.string(forKey: titleColorKey) ?? "#595959"
        self.headerSendText = UserDefaults.standard.string(forKey: sendTextKey) ?? "send"
        self.headerSendSize = UserDefaults.standard.object(forKey: sendSizeKey) != nil ? UserDefaults.standard.double(forKey: sendSizeKey) : 13.5
        self.headerSendWeightName = UserDefaults.standard.string(forKey: sendWeightKey) ?? "bold"
        self.headerSendColorHex = UserDefaults.standard.string(forKey: sendColorKey) ?? "#595959"
        self.sendIconSize = UserDefaults.standard.object(forKey: sendIconSizeKey) != nil ? UserDefaults.standard.double(forKey: sendIconSizeKey) : 25.0
        self.sendIconColorHex = UserDefaults.standard.string(forKey: sendIconColorKey) ?? "#595959"
        self.sendIconOffsetX = UserDefaults.standard.object(forKey: sendIconOffsetXKey) != nil ? UserDefaults.standard.double(forKey: sendIconOffsetXKey) : 2.0
        self.sendIconOffsetY = UserDefaults.standard.object(forKey: sendIconOffsetYKey) != nil ? UserDefaults.standard.double(forKey: sendIconOffsetYKey) : 0.0
        self.authorName = UserDefaults.standard.string(forKey: authorNameKey) ?? "User"
        self.authorNameSize = UserDefaults.standard.object(forKey: authorNameSizeKey) != nil ? UserDefaults.standard.double(forKey: authorNameSizeKey) : 13.5
        self.authorNameWeightName = UserDefaults.standard.string(forKey: authorNameWeightKey) ?? "bold"
        self.authorNameColorHex = UserDefaults.standard.string(forKey: authorNameColorKey) ?? "#000000"
        self.authorSubText = UserDefaults.standard.string(forKey: subTextKey) ?? "中国 · 上海"
        self.authorSubTextSize = UserDefaults.standard.object(forKey: subTextSizeKey) != nil ? UserDefaults.standard.double(forKey: subTextSizeKey) : 10.5
        self.authorSubTextWeightName = UserDefaults.standard.string(forKey: subTextWeightKey) ?? "medium"
        self.authorSubTextColorHex = UserDefaults.standard.string(forKey: subTextColorKey) ?? "#8E8E93"
        
        // 🌟 默认开启且选用图片中的标准镂空倒水滴
        self.showLocationIcon = UserDefaults.standard.object(forKey: showLocationIconKey) != nil ? UserDefaults.standard.bool(forKey: showLocationIconKey) : true
        self.selectedLocationIcon = UserDefaults.standard.string(forKey: locationIconKey) ?? "classic_pin"
        self.locationIconColorHex = UserDefaults.standard.string(forKey: locationIconColorKey) ?? "#8E8E93"
        self.mentionColorHex = UserDefaults.standard.string(forKey: mentionColorKey) ?? "#007AFF"
        
        self.contentText = UserDefaults.standard.string(forKey: contentTextKey) ?? "此刻在想什么... @好友"
        self.contentTextSize = UserDefaults.standard.object(forKey: contentTextSizeKey) != nil ? UserDefaults.standard.double(forKey: contentTextSizeKey) : 12.0
        self.contentTextWeightName = UserDefaults.standard.string(forKey: contentTextWeightKey) ?? "medium"
        self.contentTextColorHex = UserDefaults.standard.string(forKey: contentTextColorKey) ?? "#B8B8B8"
        
        AutoTranslationManager.shared.prewarm(text: headerCancelText)
        AutoTranslationManager.shared.prewarm(text: headerTitle)
        AutoTranslationManager.shared.prewarm(text: authorName)
        AutoTranslationManager.shared.prewarm(text: contentText)
    }
}

// 🌟 1:1 绘制图片中“实心倒水滴 + 中心圆孔”的标准地图坐标矢量 Shape
struct ClassicLocationPinShape: Shape {
    func path(in rect: CGRect) -> Path {
        let w = rect.width
        let h = rect.height
        let s = min(w / 24.0, h / 28.0)
        let offsetX = (w - 24.0 * s) / 2.0
        let offsetY = (h - 28.0 * s) / 2.0
        
        var path = Path()
        // 倒水滴外轮廓
        path.move(to: CGPoint(x: 12, y: 2))
        path.addCurve(to: CGPoint(x: 4, y: 10),
                      control1: CGPoint(x: 7.58, y: 2),
                      control2: CGPoint(x: 4, y: 5.58))
        path.addCurve(to: CGPoint(x: 12, y: 26),
                      control1: CGPoint(x: 4, y: 16.2),
                      control2: CGPoint(x: 12, y: 26))
        path.addCurve(to: CGPoint(x: 20, y: 10),
                      control1: CGPoint(x: 12, y: 26),
                      control2: CGPoint(x: 20, y: 16.2))
        path.addCurve(to: CGPoint(x: 12, y: 2),
                      control1: CGPoint(x: 20, y: 5.58),
                      control2: CGPoint(x: 16.42, y: 2))
        path.closeSubpath()
        
        // 中心镂空圆孔
        let holeRadius: CGFloat = 3.6
        path.addEllipse(in: CGRect(x: 12 - holeRadius,
                                   y: 10 - holeRadius,
                                   width: holeRadius * 2,
                                   height: holeRadius * 2))
        
        let transform = CGAffineTransform(translationX: offsetX, y: offsetY).scaledBy(x: s, y: s)
        return path.applying(transform)
    }
}

// 🌟 原生坐标渲染组件
struct InsLocationIconView: View {
    let iconName: String
    let size: CGFloat
    let color: Color
    
    var body: some View {
        if iconName == "classic_pin" || iconName.isEmpty {
            ClassicLocationPinShape()
                .fill(color, style: FillStyle(eoFill: true))
                .frame(width: size * 0.85, height: size * 1.0)
        } else if UIImage(systemName: iconName) != nil {
            Image(systemName: iconName)
                .font(.system(size: size, weight: .medium))
                .foregroundColor(color)
        } else {
            ClassicLocationPinShape()
                .fill(color, style: FillStyle(eoFill: true))
                .frame(width: size * 0.85, height: size * 1.0)
        }
    }
}

// 🌟 解析并渲染艾特（@）符号自动高亮变色
private func buildMentionText(from text: String, baseColor: Color, mentionColor: Color) -> Text {
    guard text.contains("@") else {
        return Text(text).foregroundColor(baseColor)
    }
    let pattern = "@[^\\s@,，。!！?？]+"
    guard let regex = try? NSRegularExpression(pattern: pattern, options: []) else {
        return Text(text).foregroundColor(baseColor)
    }
    let nsText = text as NSString
    let matches = regex.matches(in: text, options: [], range: NSRange(location: 0, length: nsText.length))
    
    var result = Text("")
    var lastIndex = 0
    
    for match in matches {
        let matchRange = match.range
        if matchRange.location > lastIndex {
            let normalPart = nsText.substring(with: NSRange(location: lastIndex, length: matchRange.location - lastIndex))
            result = result + Text(normalPart).foregroundColor(baseColor)
        }
        let mentionPart = nsText.substring(with: matchRange)
        result = result + Text(mentionPart).foregroundColor(mentionColor)
        lastIndex = matchRange.location + matchRange.length
    }
    
    if lastIndex < nsText.length {
        let remainingPart = nsText.substring(from: lastIndex)
        result = result + Text(remainingPart).foregroundColor(baseColor)
    }
    
    return result
}

struct InsPostWidget4x4View: View {
    @ObservedObject var manager: InsPostWidgetManager = .shared
    var showDashedBorder: Bool = false
    var onDeletePostImage: (() -> Void)? = nil
    
    @State private var selectedPostItem: PhotosPickerItem? = nil
    @ObservedObject var translator = AutoTranslationManager.shared
    @ObservedObject var appearance = SystemAppearance.shared
    
    private func effectiveWeight(_ customWeight: Font.Weight) -> Font.Weight {
        appearance.preferWidgetFontPriority ? customWeight : appearance.systemFontWeight
    }
    
    var body: some View {
        let s = uiScale // 🌟 注入全局放大系数
        
        ZStack(alignment: .topLeading) {
            Group {
                if manager.isTransparentBackground { Color.clear } else { manager.backgroundColor }
            }
            .clipShape(RoundedRectangle(cornerRadius: 26 * s, style: .continuous))
            
            VStack(alignment: .leading, spacing: 0) {
                ZStack {
                    HStack {
                        Text(translator.translate(manager.headerCancelText))
                            .font(.system(size: CGFloat(manager.headerCancelSize) * s))
                            .fontWeight(effectiveWeight(manager.headerCancelWeight))
                            .foregroundColor(manager.headerCancelColor)
                        Spacer()
                        HStack(spacing: 0 * s) {
                            Text(translator.translate(manager.headerSendText))
                                .font(.system(size: CGFloat(manager.headerSendSize) * s))
                                .fontWeight(effectiveWeight(manager.headerSendWeight))
                                .foregroundColor(manager.headerSendColor)
                            InsSendPlaneIcon(size: CGFloat(manager.sendIconSize) * s, color: manager.sendIconColor)
                                .offset(x: CGFloat(manager.sendIconOffsetX) * s, y: CGFloat(manager.sendIconOffsetY) * s)
                        }
                    }
                    Text(translator.translate(manager.headerTitle))
                        .font(.system(size: CGFloat(manager.headerTitleSize) * s))
                        .fontWeight(effectiveWeight(manager.headerTitleWeight))
                        .foregroundColor(manager.headerTitleColor)
                }
                .padding(.horizontal, 6 * s)
                .padding(.top, 8 * s)
                
                Spacer(minLength: 35 * s)
                
                HStack(spacing: 12 * s) {
                    Group {
                        if let data = manager.avatarImageData, let uiImage = ImageBitmapCache.shared.image(from: data) {
                            Image(uiImage: uiImage).resizable().scaledToFill()
                        } else {
                            ZStack {
                                Color(UIColor.systemGray5)
                                Image(systemName: "person.fill").font(.system(size: CGFloat(manager.avatarSize * 0.44) * s)).foregroundColor(.secondary)
                            }
                        }
                    }
                    .frame(width: CGFloat(manager.avatarSize) * s, height: CGFloat(manager.avatarSize) * s)
                    .clipShape(Circle())
                    .overlay(Circle().stroke(Color.primary.opacity(0.06), lineWidth: 0.8 * s))
                    
                    VStack(alignment: .leading, spacing: 3.5 * s) {
                        Text(translator.translate(manager.authorName))
                            .font(.system(size: CGFloat(manager.authorNameSize) * s))
                            .fontWeight(effectiveWeight(manager.authorNameWeight))
                            .foregroundColor(manager.authorNameColor)
                        
                        // 🌟 标准倒水滴坐标 + 自定义地区文本
                        HStack(spacing: 3 * s) {
                            if manager.showLocationIcon {
                                InsLocationIconView(
                                    iconName: manager.selectedLocationIcon,
                                    size: CGFloat(manager.authorSubTextSize * 1.05) * s,
                                    color: manager.locationIconColor
                                )
                            }
                            buildMentionText(
                                from: translator.translate(manager.authorSubText),
                                baseColor: manager.authorSubTextColor,
                                mentionColor: manager.mentionColor
                            )
                            .font(.system(size: CGFloat(manager.authorSubTextSize) * s))
                            .fontWeight(effectiveWeight(manager.authorSubTextWeight))
                            .lineLimit(1)
                        }
                    }
                    Spacer()
                }
                .padding(.horizontal, 12 * s)
                
                Spacer(minLength: 14 * s)
                
                // 🌟 发帖正文（带 @ 自动高亮）
                buildMentionText(
                    from: translator.translate(manager.contentText),
                    baseColor: manager.contentTextColor,
                    mentionColor: manager.mentionColor
                )
                .font(.system(size: CGFloat(manager.contentTextSize) * s))
                .fontWeight(effectiveWeight(manager.contentTextWeight))
                .padding(.horizontal, 10 * s)
                
                Spacer(minLength: 45 * s)
                
                HStack(spacing: 14 * s) {
                    ZStack(alignment: .topTrailing) {
                        if let postData = manager.postImageData, let postUiImg = ImageBitmapCache.shared.image(from: postData) {
                            Image(uiImage: postUiImg).resizable().scaledToFill()
                                .frame(width: 96 * s, height: 96 * s)
                                .clipShape(RoundedRectangle(cornerRadius: 20 * s, style: .continuous))
                                .overlay(RoundedRectangle(cornerRadius: 20 * s, style: .continuous).stroke(Color.primary.opacity(0.06), lineWidth: 0.8 * s))
                            
                            Button(action: { 
                                withAnimation { manager.postImageData = nil }
                                onDeletePostImage?() 
                            }) {
                                ZStack {
                                    Circle().fill(Color.black.opacity(0.28)).frame(width: 22 * s, height: 22 * s)
                                    Image(systemName: "xmark").font(.system(size: 10 * s, weight: .bold)).foregroundColor(.white)
                                }
                            }
                            .padding(6 * s)
                        } else {
                            PhotosPicker(selection: $selectedPostItem, matching: .images, photoLibrary: .shared()) {
                                ZStack {
                                    RoundedRectangle(cornerRadius: 20 * s, style: .continuous).fill(Color(hex: "#F9F9F9")).frame(width: 96 * s, height: 96 * s)
                                    Image(systemName: "photo").font(.system(size: 24 * s)).foregroundColor(manager.contentTextColor.opacity(0.55))
                                }
                            }
                            .buttonStyle(.plain)
                        }
                    }
                    
                    PhotosPicker(selection: $selectedPostItem, matching: .images, photoLibrary: .shared()) {
                        ZStack {
                            RoundedRectangle(cornerRadius: 20 * s, style: .continuous).fill(Color(hex: "#F9F9F9")).frame(width: 96 * s, height: 96 * s)
                            Image(systemName: "plus").font(.system(size: 26 * s, weight: .medium)).foregroundColor(manager.contentTextColor.opacity(0.65))
                        }
                    }
                    .buttonStyle(.plain)
                    
                    Spacer()
                }
                .padding(.horizontal, 4 * s)
                .padding(.bottom, 14 * s)
            }
            .padding(16 * s)
            
            Group {
                if manager.hasBorder {
                    RoundedRectangle(cornerRadius: 26 * s, style: .continuous).stroke(manager.borderColor, lineWidth: CGFloat(manager.borderWidth) * s)
                } else if manager.isTransparentBackground && showDashedBorder {
                    RoundedRectangle(cornerRadius: 26 * s, style: .continuous).stroke(Color.secondary.opacity(0.4), style: StrokeStyle(lineWidth: 1 * s, dash: [5 * s, 4 * s]))
                }
            }
            .allowsHitTesting(false)
        }
        .clipShape(RoundedRectangle(cornerRadius: 26 * s, style: .continuous))
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .task(id: selectedPostItem) {
            if let data = try? await selectedPostItem?.loadTransferable(type: Data.self) {
                withAnimation(.easeInOut(duration: 0.25)) {
                    manager.postImageData = data
                }
                UINotificationFeedbackGenerator().notificationOccurred(.success)
            }
        }
    }
}

extension WidgetRegistry {
    func registerInsWidget() {
        let mgr = InsPostWidgetManager.shared
        let s = uiScale // 🌟 注入全局放大系数
        registerWidget(
            id: "ins",
            title: "widget_ins_title",
            subtitle: "sub_ins",
            badge: "4×4",
            manager: mgr,
            desktopView: {
                InsPostWidget4x4View(manager: mgr)
            },
            previewView: {
                InsPostWidget4x4View(manager: mgr)
                    .frame(height: 330 * s)
                    .scaleEffect(0.68)
                    .frame(height: 235 * s)
            },
            editSheetView: { show in
                EditInsWidgetSheet(isPresented: show)
            }
        )
    }
}
